# JCL API Specification Standard

**Version:** 1.0.0  
**Date:** October 2025  
**Organization:** 2 Paws Machine and Engineering

---

## Overview

This document defines the standard format for API specifications in the JCL API Gateway system. Every COBOL/AILANG program exposed as a REST API must have a corresponding JSON specification file registered in the `api_registry` table.

---

## Specification File Format

### File Naming Convention

```
{PROGRAM_NAME}.api.json
```

**Examples:**
- `PAYROLL.api.json`
- `INVENTORY.api.json`
- `CUSTOMER_LOOKUP.api.json`

### File Location

All API specification files should be stored in:
```
PROGRAMS/{PROGRAM_NAME}.api.json
```

---

## JSON Schema

### Root Level Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `program` | string | ✓ | Program name (must match executable) |
| `version` | string | ✓ | Semantic version (e.g., "1.0.0") |
| `description` | string | ✓ | Brief description of the program |
| `maintainer` | string | ○ | Person/team responsible |
| `database_operations` | object | ○ | Tables accessed by program |
| `endpoints` | array | ✓ | List of REST endpoints |
| `error_codes` | object | ○ | Custom error code definitions |
| `rate_limits` | object | ○ | Rate limiting configuration |
| `notes` | array | ○ | Additional documentation |

### database_operations Object

```json
{
  "reads": ["table1", "table2"],
  "writes": ["table1"],
  "creates": ["temp_table"]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `reads` | array[string] | Tables this program reads from |
| `writes` | array[string] | Tables this program writes to |
| `creates` | array[string] | Temporary tables created |

### endpoints Array

Each endpoint object contains:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `path` | string | ✓ | URL path (e.g., "/api/payroll/employees") |
| `method` | string | ✓ | HTTP method (GET, POST, PUT, DELETE) |
| `action` | string | ✓ | Internal action name for routing |
| `description` | string | ✓ | What this endpoint does |
| `authentication` | boolean | ○ | Requires auth (default: false) |
| `parameters` | object | ○ | Request body parameters |
| `query_parameters` | object | ○ | URL query string parameters |
| `returns` | object | ✓ | Response schema |
| `example_request` | object | ○ | Sample request body |
| `example_response` | object | ○ | Sample response body |

### parameter Definition

```json
{
  "parameter_name": {
    "type": "string|integer|decimal|boolean|array|object",
    "required": true,
    "location": "body|path|query",
    "min": 0,
    "max": 100,
    "min_length": 1,
    "max_length": 50,
    "pattern": "^[A-Za-z]+$",
    "default": "value",
    "description": "Parameter description"
  }
}
```

### returns Definition

```json
{
  "type": "object|array",
  "properties": {
    "field_name": "type_or_description"
  }
}
```

---

## Complete Example

```json
{
  "program": "PAYROLL",
  "version": "1.0.0",
  "description": "Employee payroll processing system",
  "maintainer": "Payroll Team",
  "database_operations": {
    "reads": ["employees", "time_cards"],
    "writes": ["payroll_history", "checks"],
    "creates": []
  },
  "endpoints": [
    {
      "path": "/api/payroll/employees",
      "method": "GET",
      "action": "LIST_EMPLOYEES",
      "description": "Retrieve all employees",
      "authentication": false,
      "query_parameters": {
        "limit": {
          "type": "integer",
          "required": false,
          "default": 100
        }
      },
      "returns": {
        "type": "object",
        "properties": {
          "status": "string",
          "employees": "array"
        }
      },
      "example_response": {
        "status": "success",
        "employees": [
          {"employee_id": 1, "name": "John Doe"}
        ]
      }
    },
    {
      "path": "/api/payroll/employee",
      "method": "POST",
      "action": "ADD_EMPLOYEE",
      "description": "Add new employee",
      "parameters": {
        "name": {
          "type": "string",
          "required": true,
          "min_length": 1,
          "max_length": 50
        },
        "hourly_rate": {
          "type": "decimal",
          "required": true,
          "min": 0.01,
          "max": 999.99
        }
      },
      "returns": {
        "type": "object",
        "properties": {
          "status": "string",
          "employee_id": "integer"
        }
      },
      "example_request": {
        "name": "Jane Smith",
        "hourly_rate": 25.50
      },
      "example_response": {
        "status": "success",
        "employee_id": 42
      }
    }
  ],
  "error_codes": {
    "1001": "Employee not found",
    "1002": "Invalid employee data",
    "1003": "Database error"
  },
  "rate_limits": {
    "requests_per_minute": 60,
    "burst": 10
  },
  "notes": [
    "All monetary values stored as cents",
    "Tax rate fixed at 20%"
  ]
}
```

---

## HTTP Methods

| Method | Usage | Typical Action Names |
|--------|-------|---------------------|
| GET | Retrieve data | LIST_*, GET_*, SEARCH_* |
| POST | Create new resource | ADD_*, CREATE_*, PROCESS_* |
| PUT | Update existing resource | UPDATE_*, MODIFY_*, SET_* |
| DELETE | Remove resource | DELETE_*, REMOVE_* |

---

## Path Conventions

### RESTful Naming

```
/api/{program}/{resource}          - Collection
/api/{program}/{resource}/:id      - Single item
/api/{program}/{resource}/:id/{sub} - Sub-resource
```

### Examples

```
GET    /api/payroll/employees           - List all
GET    /api/payroll/employee/:id        - Get one
POST   /api/payroll/employee            - Create
PUT    /api/payroll/employee/:id        - Update
DELETE /api/payroll/employee/:id        - Delete
POST   /api/payroll/process             - Action
```

---

## Action Naming Conventions

Actions are internal identifiers used by programs to route requests.

### Standard Patterns

| Pattern | Example | Description |
|---------|---------|-------------|
| `LIST_{RESOURCE}` | LIST_EMPLOYEES | Retrieve collection |
| `GET_{RESOURCE}` | GET_EMPLOYEE | Retrieve single item |
| `ADD_{RESOURCE}` | ADD_EMPLOYEE | Create new item |
| `UPDATE_{RESOURCE}` | UPDATE_EMPLOYEE | Modify existing item |
| `DELETE_{RESOURCE}` | DELETE_EMPLOYEE | Remove item |
| `CALCULATE_{THING}` | CALCULATE_PAYROLL | Perform calculation |
| `PROCESS_{THING}` | PROCESS_BATCH | Execute batch operation |
| `SEARCH_{THING}` | SEARCH_ORDERS | Query with filters |

### Guidelines

1. **Use UPPERCASE with underscores**
2. **Be descriptive and unambiguous**
3. **Keep actions consistent across programs**
4. **Avoid abbreviations unless standard (e.g., ID, SQL)**

---

## Parameter Types

### Supported Types

| Type | Description | Storage | Example |
|------|-------------|---------|---------|
| `string` | Text value | VARCHAR | "John Doe" |
| `integer` | Whole number | INT | 42 |
| `decimal` | Decimal number | Store as INT (cents/hundredths) | 25.50 → 2550 |
| `boolean` | True/false | INT (0/1) | true → 1 |
| `array` | List of values | JSONB | ["a","b","c"] |
| `object` | Nested structure | JSONB | {"key":"value"} |

### Decimal Handling

**Important:** Due to floating-point precision issues, store decimals as integers:

- **Money:** Store in cents (25.50 → 2550)
- **Hours:** Store in hundredths (40.00 → 4000)
- **Percentages:** Store in basis points (20.5% → 2050)

---

## Response Standards

### Success Response

```json
{
  "status": "success",
  "data": { /* your data */ },
  "message": "Optional success message"
}
```

### Error Response

```json
{
  "status": "error",
  "error_code": 1001,
  "message": "Human-readable error",
  "details": "Additional context"
}
```

### Collection Response

```json
{
  "status": "success",
  "items": [ /* array of items */ ],
  "total": 100,
  "page": 1,
  "per_page": 25
}
```

---

## Validation Rules

### Required Validations

Every API specification must:

1. ✓ Be valid JSON
2. ✓ Include `program`, `version`, `endpoints`
3. ✓ Have at least one endpoint
4. ✓ Each endpoint must have `path`, `method`, `action`, `returns`
5. ✓ Action names must be unique within a program
6. ✓ Paths must be unique per method

### Validation Script

```bash
./register_api.sh validate PROGRAMS/YOUR_PROGRAM.api.json
```

---

## Registration Process

### Manual Registration

```bash
./register_api.sh register PROGRAMS/PAYROLL.api.json
```

### Bulk Registration

```bash
./register_api.sh register-all
```

### Database Query

```sql
INSERT INTO api_registry (program, version, spec, description)
VALUES (
    'PAYROLL',
    '1.0.0',
    '{ /* JSON spec */ }'::jsonb,
    'Payroll system'
);
```

---

## Versioning Strategy

### Semantic Versioning

Use semantic versioning: `MAJOR.MINOR.PATCH`

- **MAJOR:** Breaking changes (incompatible API changes)
- **MINOR:** New features (backward compatible)
- **PATCH:** Bug fixes (backward compatible)

### Version Management

```json
{
  "program": "PAYROLL",
  "version": "2.0.0",
  "deprecated_versions": ["1.0.0", "1.5.0"],
  "endpoints": [ /* ... */ ]
}
```

### URL Versioning (Optional)

```
/api/v1/payroll/employees
/api/v2/payroll/employees
```

---

## Security Considerations

### Authentication

```json
{
  "endpoints": [
    {
      "path": "/api/payroll/salaries",
      "authentication": true,
      "authorization": ["admin", "payroll_manager"]
    }
  ]
}
```

### Rate Limiting

```json
{
  "rate_limits": {
    "requests_per_minute": 60,
    "burst": 10,
    "per_user": true
  }
}
```

### Input Sanitization

Always define:
- `min_length` / `max_length` for strings
- `min` / `max` for numbers
- `pattern` (regex) for validation
- `required` flag

---

## Documentation Standards

### Endpoint Documentation

Each endpoint should include:

1. **Clear description** - What it does
2. **Parameters** - All inputs with types and constraints
3. **Returns** - Response structure
4. **Examples** - Request and response samples
5. **Error codes** - Possible error conditions

### Program Documentation

Include in `notes` array:
- Data precision handling (cents, hundredths)
- Business rules
- Dependencies
- Known limitations
- Performance characteristics

---

## Testing Requirements

Before registering an API:

1. ✓ Validate JSON syntax
2. ✓ Test all endpoints with curl
3. ✓ Verify error handling
4. ✓ Check response formats
5. ✓ Run automated test suite
6. ✓ Load test if high-traffic expected

```bash
# Validate spec
./register_api.sh validate PROGRAMS/YOUR_API.api.json

# Run tests
./test_api.sh
```

---

## Migration from Legacy Systems

### COBOL DIVISION Mapping

| COBOL Section | API Equivalent |
|---------------|----------------|
| IDENTIFICATION | `program`, `version`, `description` |
| ENVIRONMENT | `database_operations` |
| DATA DIVISION | `parameters`, `returns` types |
| PROCEDURE DIVISION | `action` names |

### Example Mapping

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. PAYROLL.
AUTHOR. Finance Team.

PROCEDURE DIVISION.
    PERFORM LIST-EMPLOYEES.
    PERFORM ADD-EMPLOYEE.
```

Maps to:
```json
{
  "program": "PAYROLL",
  "maintainer": "Finance Team",
  "endpoints": [
    {"action": "LIST_EMPLOYEES"},
    {"action": "ADD_EMPLOYEE"}
  ]
}
```

---

## Best Practices

### DO

✓ Use descriptive action names  
✓ Include example requests/responses  
✓ Document all error codes  
✓ Specify parameter constraints  
✓ Version your APIs  
✓ Keep endpoints RESTful  
✓ Use consistent naming  

### DON'T

✗ Use abbreviations in paths  
✗ Mix conventions (camelCase vs snake_case)  
✗ Omit required fields  
✗ Forget to validate input  
✗ Expose internal implementation details  
✗ Break backward compatibility without major version bump  

---

## Appendix: Complete Schema

### JSON Schema Definition

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["program", "version", "endpoints"],
  "properties": {
    "program": {"type": "string", "pattern": "^[A-Z_]+$"},
    "version": {"type": "string", "pattern": "^\\d+\\.\\d+\\.\\d+$"},
    "description": {"type": "string"},
    "maintainer": {"type": "string"},
    "database_operations": {
      "type": "object",
      "properties": {
        "reads": {"type": "array", "items": {"type": "string"}},
        "writes": {"type": "array", "items": {"type": "string"}},
        "creates": {"type": "array", "items": {"type": "string"}}
      }
    },
    "endpoints": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": ["path", "method", "action", "returns"],
        "properties": {
          "path": {"type": "string"},
          "method": {"enum": ["GET", "POST", "PUT", "DELETE", "PATCH"]},
          "action": {"type": "string"},
          "description": {"type": "string"},
          "authentication": {"type": "boolean"},
          "parameters": {"type": "object"},
          "query_parameters": {"type": "object"},
          "returns": {"type": "object"},
          "example_request": {"type": "object"},
          "example_response": {"type": "object"}
        }
      }
    },
    "error_codes": {"type": "object"},
    "rate_limits": {"type": "object"},
    "notes": {"type": "array", "items": {"type": "string"}}
  }
}
```

---

## Summary

This specification standard ensures:

- **Consistency** across all APIs
- **Discoverability** through self-documentation
- **Type safety** with parameter validation
- **Maintainability** with clear versioning
- **Scalability** through standardization

**Next Steps:** Start creating your API specifications using this standard!