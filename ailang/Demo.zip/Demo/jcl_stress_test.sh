#!/bin/bash
# jcl_stress_test.sh
# Stress test for JCL daemon parallel worker pool

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║        JCL DAEMON STRESS TEST                             ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if daemon is running
echo -e "${YELLOW}[CHECK]${NC} Verifying daemon is running..."
if ! pgrep -f "JCL_daemon_exec" > /dev/null; then
    echo -e "${RED}[ERROR]${NC} JCL daemon is not running!"
    echo "Start it with: ./JCL_daemon_exec"
    exit 1
fi
echo -e "${GREEN}[OK]${NC} Daemon is running"
echo ""

# Check if gateway is running
echo -e "${YELLOW}[CHECK]${NC} Verifying HTTP gateway is running..."
if ! pgrep -f "JCL_http_gateway_exec" > /dev/null; then
    echo -e "${RED}[ERROR]${NC} HTTP gateway is not running!"
    echo "Start it with: ./JCL_http_gateway_exec"
    exit 1
fi
echo -e "${GREEN}[OK]${NC} Gateway is running"
echo ""

# Test 1: Single job submission
echo "════════════════════════════════════════════════════════════"
echo "TEST 1: Single Job Submission"
echo "════════════════════════════════════════════════════════════"
echo -e "${YELLOW}[TEST]${NC} Submitting single HELLOWORLD job..."
response=$(curl -s -X POST http://localhost:8080/submit -d '{"job":"HELLOWORLD"}')
echo "Response: $response"
if [[ $response == *"success"* ]]; then
    echo -e "${GREEN}[PASS]${NC} Single job submitted"
else
    echo -e "${RED}[FAIL]${NC} Job submission failed"
fi
sleep 2
echo ""

# Test 2: Rapid fire - 10 jobs
echo "════════════════════════════════════════════════════════════"
echo "TEST 2: Rapid Fire - 10 Jobs Simultaneously"
echo "════════════════════════════════════════════════════════════"
echo -e "${YELLOW}[TEST]${NC} Submitting 10 jobs in parallel..."
success_count=0
fail_count=0

for i in {1..10}; do
    response=$(curl -s -X POST http://localhost:8080/submit -d '{"job":"PAYROLL_BATCH"}') &
done
wait

sleep 1
echo -e "${GREEN}[DONE]${NC} 10 jobs submitted"
echo ""

# Test 3: Mixed workload
echo "════════════════════════════════════════════════════════════"
echo "TEST 3: Mixed Workload"
echo "════════════════════════════════════════════════════════════"
echo -e "${YELLOW}[TEST]${NC} Submitting mixed job types..."

jobs=("HELLOWORLD" "PAYROLL_BATCH" "PAYROLL" "PAYROLL_BATCH" "HELLOWORLD")
for job in "${jobs[@]}"; do
    response=$(curl -s -X POST http://localhost:8080/submit -d "{\"job\":\"$job\"}")
    if [[ $response == *"success"* ]]; then
        echo -e "${GREEN}✓${NC} $job submitted"
    else
        echo -e "${RED}✗${NC} $job failed"
    fi
    sleep 0.1
done
sleep 2
echo ""

# Test 4: Check worker parallelism
echo "════════════════════════════════════════════════════════════"
echo "TEST 4: Worker Parallelism Check"
echo "════════════════════════════════════════════════════════════"
echo -e "${YELLOW}[TEST]${NC} Submitting 20 jobs and monitoring workers..."

# Submit jobs in background
for i in {1..20}; do
    curl -s -X POST http://localhost:8080/submit -d '{"job":"PAYROLL_BATCH"}' > /dev/null &
done

# Monitor for 10 seconds
echo "Monitoring active workers for 10 seconds..."
max_workers=0
for i in {1..20}; do
    active=$(ps aux | grep "PAYROLL_BATCH.jcl" | grep -v grep | wc -l)
    if [ $active -gt $max_workers ]; then
        max_workers=$active
    fi
    echo -ne "\rActive workers: $active (max seen: $max_workers)  "
    sleep 0.5
done
echo ""

if [ $max_workers -ge 2 ]; then
    echo -e "${GREEN}[PASS]${NC} Parallel execution confirmed (max $max_workers workers)"
else
    echo -e "${YELLOW}[WARN]${NC} Expected parallel workers, saw max $max_workers"
fi
echo ""

# Test 5: Stress test
echo "════════════════════════════════════════════════════════════"
echo "TEST 5: Stress Test - 50 Jobs"
echo "════════════════════════════════════════════════════════════"
echo -e "${YELLOW}[TEST]${NC} Submitting 50 jobs as fast as possible..."

start_time=$(date +%s)
for i in {1..50}; do
    curl -s -X POST http://localhost:8080/submit -d '{"job":"PAYROLL_BATCH"}' > /dev/null &
    if [ $((i % 10)) -eq 0 ]; then
        echo "  Submitted $i/50 jobs..."
    fi
done
wait

end_time=$(date +%s)
duration=$((end_time - start_time))

echo -e "${GREEN}[DONE]${NC} All 50 jobs submitted in ${duration}s"
echo "Average: $((50 / duration)) jobs/second submission rate"
echo ""

# Wait for completion
echo -e "${YELLOW}[WAIT]${NC} Waiting for all jobs to complete..."
sleep 5

# Check database
echo ""
echo "════════════════════════════════════════════════════════════"
echo "DATABASE CHECK"
echo "════════════════════════════════════════════════════════════"
echo -e "${YELLOW}[CHECK]${NC} Querying database for results..."
if command -v psql &> /dev/null; then
    file_count=$(psql -d testdb -t -c "SELECT COUNT(*) FROM cobol_files WHERE filename='PAYROLL_AUTOMATED.txt';" 2>/dev/null || echo "0")
    echo "Files in database: $file_count"
    
    latest=$(psql -d testdb -t -c "SELECT modified_at FROM cobol_files WHERE filename='PAYROLL_AUTOMATED.txt' ORDER BY modified_at DESC LIMIT 1;" 2>/dev/null || echo "N/A")
    echo "Latest update: $latest"
else
    echo -e "${YELLOW}[SKIP]${NC} psql not available, skipping DB check"
fi
echo ""

# Summary
echo "════════════════════════════════════════════════════════════"
echo "TEST SUMMARY"
echo "════════════════════════════════════════════════════════════"
echo -e "${GREEN}✓${NC} Single job submission"
echo -e "${GREEN}✓${NC} Rapid fire (10 jobs)"
echo -e "${GREEN}✓${NC} Mixed workload"
echo -e "${GREEN}✓${NC} Parallel execution (max $max_workers workers)"
echo -e "${GREEN}✓${NC} Stress test (50 jobs in ${duration}s)"
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║              STRESS TEST COMPLETE                         ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo "Check daemon logs for detailed execution traces"
echo "Run: tail -f logs/*.log"