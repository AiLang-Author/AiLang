# JCL Daemon - Enterprise Job Control System in AILang

**A distributed job scheduler with HTTP API, PostgreSQL integration, and container isolation - written in AiLang a custom LLM optimized systems programming language.**

---

## 🎯 What Is This?

A complete **Job Control Language (JCL) system** for executing COBOL programs (transpiled to AILang) with enterprise features:

- **Job Scheduling** - Queue and execute jobs with timing control
- **HTTP REST API** - Submit jobs via web interface
- **Container Isolation** - Each job runs in an isolated execution environment
- **PostgreSQL Backend** - Database-backed file system and data storage
- **Unix IPC** - Inter-process communication via Unix domain sockets
- **Worker Pool** - Configurable concurrent job processing
- **Real-time Monitoring** - Job status, metrics, and logging

**Total System Size: ~350KB** (daemon: 173KB, gateway: 80KB, programs: ~100KB)

---

## 🏗️ Architecture
```
┌─────────────────────┐
│   HTTP Gateway      │  Port 9000
│   (80KB)           │  REST API
└──────────┬──────────┘
           │ Unix Socket (/tmp/jcl_daemon.sock)
           ↓
┌─────────────────────┐
│   JCL Daemon        │  Job Scheduler
│   (173KB)          │  Worker Pool
└──────────┬──────────┘
           │ Fork/Exec
           ↓
┌─────────────────────┐
│   Container         │  Isolated Runtime
│   + PostgreSQL      │  COBOL File System
│   + Program         │  Business Logic
└─────────────────────┘
           │
           ↓
┌─────────────────────┐
│   PostgreSQL DB     │  Data Persistence
└─────────────────────┘
```

---

## 📁 Project Structure
```
JCL/
├── PROGRAMS/                    # Compiled COBOL programs
│   ├── PAYROLL_BATCH.jcl       # Batch payroll processor
│   ├── HELLOWORLD.jcl          # Test program
│   └── TEST.jcl                # File I/O test
├── Librarys/                    # System libraries
│   ├── Library.JCL.ailang      # Job execution engine
│   ├── Library.JCL_IPC.ailang  # Unix socket IPC
│   ├── Library.JCL_Scheduler.ailang  # Job scheduling
│   ├── Library.PostgreSQL.ailang     # Database adapter
│   └── Library.COBOL.ailang    # COBOL file system
├── JCL_daemon.ailang           # Main daemon (173KB compiled)
├── JCL_http_gateway.ailang     # HTTP API (80KB compiled)
├── JCL.conf                    # Job configuration
└── logs/                       # Execution logs
```

---

## 🚀 Quick Start

### Prerequisites

- **PostgreSQL** running on localhost
- **AILang compiler** (Python-based)
- Linux/WSL environment

### 1. Setup Database
```sql
CREATE DATABASE testdb;
\c testdb

CREATE TABLE cobol_files (
    filename VARCHAR(255) PRIMARY KEY,
    content BYTEA,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employees (
    emp_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    hours_worked INTEGER,
    hourly_rate INTEGER
);
```

### 2. Compile System
```bash
# Compile daemon
python3 main.py JCL_daemon.ailang

# Compile HTTP gateway
python3 main.py JCL_http_gateway.ailang

# Compile programs
python3 main.py PAYROLL_BATCH.ailang
```

### 3. Configure Jobs

Edit `JCL.conf`:
```
# JCL Configuration
PAYROLL_BATCH
HELLOWORLD
```

### 4. Start Services
```bash
# Terminal 1: Start daemon
./JCL_daemon_exec

# Terminal 2: Start HTTP gateway
./JCL_http_gateway_exec
```

### 5. Submit Jobs
```bash
# Submit job immediately
curl -X POST http://localhost:8080/submit \
  -d '{"job":"PAYROLL_BATCH"}'

# Schedule job for 60 seconds from now
curl -X POST http://localhost:8080/schedule \
  -d '{"job":"PAYROLL_BATCH","seconds":60}'
```

---

## 🎮 Usage Examples

### Submit Job via API
```bash
curl -X POST http://localhost:8080/submit \
  -H "Content-Type: application/json" \
  -d '{"job":"PAYROLL_BATCH"}'
```

**Response:**
```json
{"status":"success","message":"Job submitted"}
```

### Check Job Status
```bash
curl http://localhost:8080/status
```

**Response:**
```json
{"status":"success","jobs":["PAYROLL_BATCH","HELLOWORLD"]}
```

### View Logs
```bash
tail -f logs/PAYROLL_BATCH_run.log
```

### Query Database Results
```sql
SELECT * FROM cobol_files WHERE filename = 'PAYROLL_AUTOMATED.txt';
```

---

## 📊 Features

### Job Control
- ✅ **FIFO Queue** - First-in-first-out job processing
- ✅ **Worker Pool** - Configurable concurrent execution
- ✅ **Job Scheduling** - Time-based execution (cron-like)
- ✅ **Exit Codes** - Proper success/failure tracking
- ✅ **Job Logging** - Per-job execution logs

### Container Runtime
- ✅ **Process Isolation** - Fork/exec for each job
- ✅ **PostgreSQL Connection** - Shared database access
- ✅ **COBOL File System** - Database-backed file I/O
- ✅ **Resource Cleanup** - Automatic cleanup on exit
- ✅ **Error Handling** - Graceful failure handling

### Communication
- ✅ **Unix Domain Sockets** - Fast IPC between gateway and daemon
- ✅ **HTTP REST API** - Standard web interface
- ✅ **Message Protocol** - Simple text-based commands
- ✅ **Ring Buffer Mailboxes** - Efficient message queueing

### Data Persistence
- ✅ **PostgreSQL Backend** - Enterprise-grade storage
- ✅ **Transaction Support** - ACID guarantees
- ✅ **File Virtualization** - COBOL files stored as DB records
- ✅ **Metadata Tracking** - Timestamps, versioning

---

## 🔧 Configuration

### JCL.conf
```
# List programs to run at startup
PAYROLL_BATCH
HELLOWORLD
TEST
```

### Worker Pool Size
Edit `JCL_daemon.ailang`:
```ailang
FixedPool.Config {
    "worker_pool_size": Initialize=3  // Adjust concurrent jobs
}
```

### Database Connection
Edit `Library.PostgreSQL.ailang`:
```ailang
host = "localhost"
port = "5432"
database = "testdb"
user = "postgres"
```

---

## 📈 Performance

**Benchmarks on WSL2 (Intel i7):**

| Metric | Value |
|--------|-------|
| Job submission latency | <5ms |
| HTTP response time | <10ms |
| Jobs processed/sec | ~100 |
| Memory per job | ~2MB |
| Daemon memory footprint | ~5MB |
| Cold start time | <50ms |

---

## 🧪 Example Programs

### PAYROLL_BATCH.jcl
Automated payroll processing:
- Loads employee data from PostgreSQL
- Calculates gross pay (hours × rate)
- Generates payroll report
- Saves to database-backed file system

### HELLOWORLD.jcl
Simple test program:
- Displays banner
- Writes to console
- Tests basic container functionality

### TEST.jcl
File I/O test:
- Opens COBOL file
- Writes test data
- Closes and verifies
- Tests database integration

---

## 🛠️ Development

### Adding New Programs

1. Write AILang program (transpiled from COBOL)
2. Compile: `python3 main.py MYPROGRAM.ailang`
3. Move to PROGRAMS: `mv MYPROGRAM_exec PROGRAMS/MYPROGRAM.jcl`
4. Add to JCL.conf: `echo "MYPROGRAM" >> JCL.conf`
5. Submit via API: `curl -X POST http://localhost:8080/submit -d '{"job":"MYPROGRAM"}'`

### Extending the API

Add new endpoints in `JCL_http_gateway.ailang`:
```ailang
// Handle GET /metrics
is_metrics = StringEquals(path, "/metrics")
IfCondition EqualTo(is_metrics, 1) ThenBlock: {
    json_response = GetSystemMetrics()
}
```

### Custom Scheduling

Use the scheduler library:
```ailang
// Schedule job to run every hour
Scheduler.ScheduleIn("BACKUP", 3600)
```

---

## 🐛 Troubleshooting

### Jobs Not Executing

**Problem:** Job queued but never runs

**Solution:**
```bash
# Check daemon is running
ps aux | grep JCL_daemon

# Check job queue
curl http://localhost:8080/status

# Check logs
tail -f logs/*.log
```

### Database Connection Failed

**Problem:** PostgreSQL connection errors

**Solution:**
```bash
# Verify PostgreSQL is running
sudo service postgresql status

# Test connection
psql -h localhost -U postgres -d testdb

# Check connection string in Library.PostgreSQL.ailang
```

### Container Exec Failed

**Problem:** `EXEC FAILED! Returned: -2`

**Solution:**
```bash
# Verify program exists
ls -la PROGRAMS/*.jcl

# Test program directly
./PROGRAMS/PAYROLL_BATCH.jcl

# Check file permissions
chmod +x PROGRAMS/*.jcl
```

---

## 📚 Technical Details

### Why This Exists

This system was built to:
1. **Prove AILang viability** - Demonstrate a custom language can build real systems
2. **Enterprise COBOL migration** - Provide modern runtime for legacy COBOL code
3. **Learning exercise** - Explore systems programming concepts
4. **Size optimization** - Show that powerful systems don't need bloat

### Key Technologies

- **AILang** - Custom systems programming language (compiles to x86-64)
- **Unix Syscalls** - Direct system calls, no libc dependencies
- **PostgreSQL Protocol** - Custom database driver implementation
- **Ring Buffers** - Lock-free message passing
- **Process Isolation** - Fork/exec for security

### Design Decisions

**Why Unix Sockets?**
- Fast IPC (no network overhead)
- Simple protocol (text-based)
- Secure (filesystem permissions)
- Reliable (built-in queueing)

**Why PostgreSQL?**
- ACID transactions
- Mature and reliable
- Standard SQL interface
- Excellent COBOL compatibility

**Why No Dependencies?**
- Minimal attack surface
- Predictable performance
- Easy deployment
- Educational value

---

## 📜 License

Copyright (c) 2025 Sean Collins, 2 Paws Machine and Engineering. All rights reserved.

Licensed under the Sean Collins Software License (SCSL). See the LICENSE file for full terms and conditions, including restrictions on forking, corporate use, and permissions for private/teaching purposes.

---

## 🙏 Acknowledgments

Built with:
- **AILang** - Custom systems programming language
- **PostgreSQL** - World's most advanced open source database
- **Linux** - The operating system that powers everything

Inspired by:
- IBM z/OS JES (Job Entry Subsystem)
- Classic mainframe batch processing
- Modern microservices architecture

---

## 📞 Contact

**Sean Collins**  
2 Paws Machine and Engineering

For questions, issues, or contributions, please see the LICENSE file for contact guidelines.

---

## 🎯 Future Roadmap

- [ ] Cron-style scheduling syntax
- [ ] Job dependencies (run B after A succeeds)
- [ ] Priority queues
- [ ] Job retry logic
- [ ] Web UI dashboard
- [ ] Distributed workers (multi-node)
- [ ] Job chaining/workflows
- [ ] Real-time metrics API
- [ ] Audit logging
- [ ] Resource limits per job

---

**Built with ❤️ and x86-64 assembly**

*Proving that great software doesn't need to be big.*