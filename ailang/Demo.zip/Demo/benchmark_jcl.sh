#!/bin/bash
# benchmark_jcl.sh

ENDPOINT="http://localhost:9000/api"
REQUESTS=1000

echo "=== JCL Gateway Benchmark ==="
echo "Endpoint: $ENDPOINT"
echo "Requests: $REQUESTS"
echo ""

start=$(date +%s.%N)

for i in $(seq 1 $REQUESTS); do
    curl -s -X POST $ENDPOINT \
        -H "Content-Type: application/json" \
        -d '{"operation":"VALIDATE","amount":5000}' \
        > /dev/null
done

end=$(date +%s.%N)

duration=$(echo "$end - $start" | bc)
rps=$(echo "$REQUESTS / $duration" | bc -l)

echo "Duration: ${duration}s"
echo "Requests/sec: $rps"
echo "Avg latency: $(echo "1000 / $rps" | bc -l)ms"