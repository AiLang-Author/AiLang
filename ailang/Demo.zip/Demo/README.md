# AILANG COBOL Modernization - Demo Package
## Quick Start Guide

**Prepared for:** U.S. Office of Personnel Management (OPM)  
**Date:** October 2025  
**Author:** Sean Collins, 2 Paws Machine and Engineering

---

## What This Demo Shows

This is a **working demonstration** of COBOL modernization technology. It runs the actual CMS Medicare ESCAL056 (End-Stage Renal Disease) payment calculator - real government COBOL code compiled to native Linux executables.

**What you'll see:**
- Legacy COBOL programs running on modern Linux (no mainframe needed)
- Web-based interface to legacy applications
- RESTful API integration
- PostgreSQL database instead of DB2/VSAM
- ~500ms response times with full debug tracing enabled

---

## Quick Start (5 Minutes)

### Prerequisites

- Linux x86_64 (Ubuntu 20.04+, RHEL 8+, or similar)
- PostgreSQL 12+
- curl (for testing)
- Web browser

### Installation

1. contact with questions

# 2. Set up PostgreSQL (see detailed section below)
sudo -u postgres psql <<EOF
CREATE DATABASE testdb;
CREATE USER testuser WITH PASSWORD 'testpass';
GRANT ALL PRIVILEGES ON DATABASE testdb TO testuser;
\c testdb
GRANT ALL ON SCHEMA public TO testuser;
EOF

# 3. Initialize database
psql -U testuser -d testdb -f init_database.sql

# 4. Make binaries executable
chmod +x JCL_daemon_exec JCL_http_gateway_exec

# 5. Start the services (in separate terminals)
./JCL_daemon_exec &
./JCL_http_gateway_exec &

# 6. Open the web interface
firefox web/index.html
# (or open web/index.html in any browser)
```

### First Test

In the web interface:
1. Click **"Pediatric Case"** preset button
2. Click **"Calculate Payment"**
3. Expected result: **✅ SUCCESS in ~500ms**

---

## PostgreSQL Setup Guide

### Installing PostgreSQL

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**RHEL/CentOS 8:**
```bash
sudo dnf install postgresql-server postgresql-contrib
sudo postgresql-setup --initdb
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**RHEL/CentOS 7:**
```bash
sudo yum install postgresql-server postgresql-contrib
sudo postgresql-setup initdb
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### Creating the Database

**Option 1: Using postgres superuser (recommended for demo)**

```bash
sudo -u postgres psql <<EOF
-- Create database
CREATE DATABASE testdb;

-- Create user with password
CREATE USER testuser WITH PASSWORD 'testpass';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE testdb TO testuser;

-- Connect to database and grant schema access (PostgreSQL 15+)
\c testdb
GRANT ALL ON SCHEMA public TO testuser;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO testuser;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO testuser;

-- Verify
\l testdb
\du testuser
EOF
```

**Option 2: Step-by-step commands**

```bash
# Switch to postgres user
sudo -u postgres psql

# Inside psql:
CREATE DATABASE testdb;
CREATE USER testuser WITH PASSWORD 'testpass';
GRANT ALL PRIVILEGES ON DATABASE testdb TO testuser;

# Connect to the new database
\c testdb

# Grant schema permissions (important for PostgreSQL 15+)
GRANT ALL ON SCHEMA public TO testuser;

# Exit
\q
```

### Initialize the Schema

```bash
# Run the initialization script
psql -U testuser -d testdb -f init_database.sql

# Verify tables were created
psql -U testuser -d testdb -c "\dt"

# Expected output:
#              List of relations
#  Schema |     Name      | Type  |  Owner
# --------+---------------+-------+----------
#  public | active_jobs   | table | testuser
#  public | cobol_files   | table | testuser
#  public | employees     | table | testuser
#  public | jcl_job_data  | table | testuser
```

### PostgreSQL Configuration Tips

**Allow local connections** (if running on same machine):

Edit `/etc/postgresql/*/main/postgresql.conf` or `/var/lib/pgsql/data/postgresql.conf`:
```
listen_addresses = 'localhost'
```

Edit `/etc/postgresql/*/main/pg_hba.conf` or `/var/lib/pgsql/data/pg_hba.conf`:
```
# TYPE  DATABASE        USER            ADDRESS                 METHOD
local   all             postgres                                peer
local   all             testuser                                md5
host    testdb          testuser        127.0.0.1/32            md5
host    testdb          testuser        ::1/128                 md5
```

**Restart PostgreSQL:**
```bash
sudo systemctl restart postgresql
```

**Test connection:**
```bash
psql -U testuser -d testdb -c "SELECT 'Connection successful!' as status;"
```

### Changing the Database Password

**In PostgreSQL:**
```sql
sudo -u postgres psql
ALTER USER testuser WITH PASSWORD 'your_new_password';
\q
```

**Update application configs:**
1. Edit `Library.JCL_Worker.ailang` → Change `DBConfig.password`
2. Edit `JCL_http_gateway.ailang` → Change `HTTPConfig.db_pass`
3. Recompile or use pre-compiled binaries with updated source

---

## Nginx Configuration Guide

### Installing Nginx

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

**RHEL/CentOS:**
```bash
sudo yum install nginx  # or: sudo dnf install nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

### Basic Configuration (Development)

Create `/etc/nginx/sites-available/ailang-demo` (Ubuntu/Debian) or `/etc/nginx/conf.d/ailang-demo.conf` (RHEL/CentOS):

```nginx
server {
    listen 80;
    server_name localhost;
    
    # Web interface
    location / {
        root /path/to/ailang-cobol-demo/web;
        index index.html;
        try_files $uri $uri/ =404;
    }
    
    # API proxy to HTTP gateway
    location /api {
        # Remove /api prefix before forwarding
        rewrite ^/api(.*)$ $1 break;
        
        # Forward to local HTTP gateway
        proxy_pass http://127.0.0.1:9000;
        proxy_http_version 1.1;
        
        # Pass headers
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        
        # Timeouts (adjust as needed)
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 300s;
        
        # CORS headers (for browser access)
        add_header Access-Control-Allow-Origin * always;
        add_header Access-Control-Allow-Methods "GET, POST, OPTIONS" always;
        add_header Access-Control-Allow-Headers "Content-Type" always;
        
        # Handle OPTIONS preflight
        if ($request_method = 'OPTIONS') {
            return 204;
        }
    }
    
    # Health check endpoint
    location /health {
        proxy_pass http://127.0.0.1:9000;
        access_log off;
    }
}
```

**Enable the site (Ubuntu/Debian):**
```bash
# Update the path in config
sudo sed -i 's|/path/to/ailang-cobol-demo|'$(pwd)'|g' /etc/nginx/sites-available/ailang-demo

# Enable site
sudo ln -s /etc/nginx/sites-available/ailang-demo /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Reload nginx
sudo systemctl reload nginx
```

**Enable the site (RHEL/CentOS):**
```bash
# Update the path in config
sudo sed -i 's|/path/to/ailang-cobol-demo|'$(pwd)'|g' /etc/nginx/conf.d/ailang-demo.conf

# Test configuration
sudo nginx -t

# Reload nginx
sudo systemctl reload nginx
```

### Update Web Interface

Edit `web/index.html` and change the API endpoint:

```javascript
// Find this line (around line 237):
const API = 'http://localhost:9000';

// Change to:
const API = '/api';  // Uses nginx proxy
```

### Test the Setup

```bash
# Test web interface
curl http://localhost/

# Test API through nginx
curl http://localhost/api

# Test direct API (should still work)
curl http://localhost:9000

# Submit test job through nginx
curl -X POST http://localhost/api \
  -H "Content-Type: application/json" \
  -d '{"program":"ESCAL056","data":{"patient_age":65}}'
```

### Production Configuration (with SSL)

For production deployment with SSL/TLS:

```nginx
# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name your-domain.gov;
    return 301 https://$server_name$request_uri;
}

# HTTPS server
server {
    listen 443 ssl http2;
    server_name your-domain.gov;
    
    # SSL certificates (obtain from your CA)
    ssl_certificate /etc/ssl/certs/your-domain.crt;
    ssl_certificate_key /etc/ssl/private/your-domain.key;
    
    # SSL settings
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # Security headers
    add_header Strict-Transport-Security "max-age=31536000" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    
    # Logs
    access_log /var/log/nginx/ailang-access.log;
    error_log /var/log/nginx/ailang-error.log;
    
    # Same location blocks as above...
    location / {
        root /path/to/ailang-cobol-demo/web;
        index index.html;
        try_files $uri $uri/ =404;
    }
    
    location /api {
        rewrite ^/api(.*)$ $1 break;
        proxy_pass http://127.0.0.1:9000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
    }
}
```

### Nginx Troubleshooting

**Check Nginx status:**
```bash
sudo systemctl status nginx
```

**Test configuration:**
```bash
sudo nginx -t
```

**View error logs:**
```bash
sudo tail -f /var/log/nginx/error.log
```

**Check if port 80 is available:**
```bash
sudo netstat -tlnp | grep :80
# or
sudo ss -tlnp | grep :80
```

**Reload configuration:**
```bash
sudo systemctl reload nginx
```

**Restart Nginx:**
```bash
sudo systemctl restart nginx
```

**SELinux issues (RHEL/CentOS):**
```bash
# Allow nginx to connect to network
sudo setsebool -P httpd_can_network_connect 1

# Check SELinux is not blocking
sudo ausearch -m avc -ts recent
```

**Firewall issues:**
```bash
# Ubuntu (UFW)
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# RHEL/CentOS (FirewallD)
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --reload
```

---

## Database Schema

### Core Table: `jcl_job_data`

Stores JSON payloads for job processing:

```sql
CREATE TABLE jcl_job_data (
    job_id BIGINT PRIMARY KEY,
    json_data TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
```

**How it works:**
1. Web interface POSTs JSON to HTTP gateway (port 9000)
2. Gateway generates unique `job_id` (timestamp-based)
3. Gateway stores JSON in `jcl_job_data` table
4. Gateway sends `SUBMIT|ESCAL056|job_id` to daemon via Unix socket
5. Daemon spawns ESCAL056 program with job_id
6. Program reads JSON from database using job_id
7. Program performs calculation
8. Program exits with status code

### Sample Data Tables

```sql
-- Example employee table (for payroll demos)
CREATE TABLE employees (
    emp_id INTEGER PRIMARY KEY,
    emp_name TEXT NOT NULL,
    hourly_rate INTEGER NOT NULL,  -- stored as cents
    hours_worked INTEGER NOT NULL
);

-- Process tracking
CREATE TABLE active_jobs (
    pid INTEGER PRIMARY KEY,
    job_id BIGINT NOT NULL,
    program_name VARCHAR(255) NOT NULL,
    started_at TIMESTAMP DEFAULT NOW()
);
```

---

## API Reference

### Submit Job

```bash
curl -X POST http://localhost:9000 \
  -H "Content-Type: application/json" \
  -d '{
    "program": "ESCAL056",
    "data": {
      "patient_age": 65,
      "patient_weight": 70.0,
      "patient_height": 170.0,
      "provider_type": "41",
      "revenue_code": "0821"
    }
  }'
```

**Response:**
```json
{"status":"success","message":"Job completed"}
```

### Check Status

```bash
curl http://localhost:9000
```

**Response:**
```json
{
  "status":"success",
  "queue_size":0,
  "jobs_submitted":0,
  "jobs_completed":0
}
```

---

## Architecture Overview

```
Browser (HTML5/JS)
    ↓ HTTP POST
HTTP Gateway (port 9000)
    ↓ Unix Socket IPC
Job Queue Daemon (/tmp/jcl_daemon.sock)
    ↓ Fork/Exec
ESCAL056 Program (compiled COBOL)
    ↓ SQL
PostgreSQL Database (testdb)
```

**Process flow:**
1. User submits via web interface
2. Gateway stores job data in PostgreSQL
3. Gateway sends job to daemon queue
4. Daemon executes program in container
5. Program reads job data from database
6. Program calculates result
7. Gateway returns success/failure

---

## Configuration

### Database Connection

**Default credentials** (change for your environment):
- Host: `localhost`
- Port: `5432`
- Database: `testdb`
- Username: `testuser`
- Password: `testpass`

These are configured in:
- `Library.JCL_Worker.ailang` (DBConfig pool)
- `JCL_http_gateway.ailang` (HTTPConfig pool)

### HTTP Port

Default port is **9000**. To change:

Edit `JCL_http_gateway.ailang`:
```ailang
FixedPool.HTTPConfig {
    "port": Initialize=9000  // Change this value
    ...
}
```

Then recompile (if source is provided) or use as-is.

---

## Running Behind Nginx

This demo is designed to run behind a reverse proxy. Simple Nginx config:

```nginx
server {
    listen 80;
    server_name your-domain.gov;
    
    # Static files (web interface)
    location / {
        root /path/to/ailang-cobol-demo/web;
        try_files $uri $uri/ =404;
    }
    
    # API proxy to HTTP gateway
    location /api {
        rewrite ^/api(.*)$ $1 break;
        proxy_pass http://127.0.0.1:9000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Update `web/index.html` API endpoint:
```javascript
// Change from:
const API = 'http://localhost:9000';

// To:
const API = 'https://your-domain.gov/api';
```

---

## Testing the Demo

### Test 1: Simple Job Submission

```bash
curl -X POST http://localhost:9000 \
  -H "Content-Type: application/json" \
  -d '{"program":"ESCAL056","data":{"patient_age":65}}'
```

### Test 2: Multiple Jobs

```bash
for i in {1..10}; do
  curl -s -X POST http://localhost:9000 \
    -H "Content-Type: application/json" \
    -d "{\"program\":\"ESCAL056\",\"data\":{\"patient_age\":$((60+i))}}" &
done
wait
```

### Test 3: Check Database

```bash
psql -U testuser -d testdb -c "
  SELECT job_id, 
         json_data::json->>'patient_age' as age,
         created_at 
  FROM jcl_job_data 
  ORDER BY created_at DESC 
  LIMIT 5;
"
```

---

## Troubleshooting

### "Daemon not running" error

```bash
# Check if daemon is running
ps aux | grep JCL_daemon

# Restart daemon
pkill JCL_daemon_exec
./JCL_daemon_exec &
```

### Database connection fails

```bash
# Test database connection
psql -U testuser -d testdb -c "SELECT 1;"

# Check PostgreSQL is running
sudo systemctl status postgresql
```

### Port 9000 already in use

```bash
# Find what's using port 9000
sudo lsof -i :9000

# Kill it or change port in HTTPConfig
```

### Jobs not processing

```bash
# Check daemon logs (it outputs to stdout)
# Clear stale jobs
psql -U testuser -d testdb -c "DELETE FROM active_jobs;"
```

---

## What's NOT in This Demo

This is a **demonstrator** showing the core technology. Production deployment would require:

- **Security:** Authentication, authorization, encryption (typically handled by your Nginx/load balancer)
- **High Availability:** Load balancing, failover, clustering
- **Monitoring:** APM, logging aggregation, alerting
- **Scalability:** Horizontal scaling, caching, optimization
- **Compliance:** Audit logging, data governance, backup/recovery

The demo runs in "development mode" with full debug tracing. Production implementations would be customized based on your specific infrastructure and security requirements.

---

## File Structure

```
ailang-cobol-demo/
├── README.md                    # This file
├── init_database.sql            # Database setup
├── JCL_daemon_exec              # Job queue daemon (compiled)
├── JCL_http_gateway_exec        # HTTP gateway (compiled)
├── JCL.conf                     # Job configuration
├── PROGRAMS/
│   └── ESCAL056.jcl             # Medicare calculator (compiled)
├── web/
│   └── index.html               # Web interface
└── source/                      # Source code (optional)
    ├── JCL_daemon.ailang
    ├── JCL_http_gateway.ailang
    ├── Library.JCL_Worker.ailang
    └── ESCAL056.ailang
```

---

## Support

**Sean Collins**  
2 Paws Machine and Engineering

For questions about this demo or production implementation:
- Email: [Your Email]
- Phone: [Your Phone]

---

## Quick Command Reference

```bash
# Start services
./JCL_daemon_exec &
./JCL_http_gateway_exec &

# Stop services
pkill JCL_daemon_exec
pkill JCL_http_gateway_exec

# Test API
curl http://localhost:9000

# Submit job
curl -X POST http://localhost:9000 \
  -H "Content-Type: application/json" \
  -d '{"program":"ESCAL056","data":{"patient_age":65}}'

# Check database
psql -U testuser -d testdb -c "SELECT * FROM jcl_job_data;"
```

---

**This is a technology demonstration showing COBOL modernization capabilities. Production deployment requires additional infrastructure planning based on your specific requirements.**