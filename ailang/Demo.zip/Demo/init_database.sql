-- ============================================================================
-- AILANG COBOL Demo - Database Initialization Script
-- ============================================================================
-- Creates all necessary tables for the demo application
-- Run this as: psql -U testuser -d testdb -f init_database.sql
-- ============================================================================

\echo '============================================================================'
\echo 'AILANG COBOL Demo - Database Initialization'
\echo '============================================================================'
\echo ''

-- ============================================================================
-- Clean up existing objects (if any)
-- ============================================================================

\echo 'Cleaning up existing objects...'

DROP TABLE IF EXISTS jcl_job_data CASCADE;
DROP TABLE IF EXISTS active_jobs CASCADE;
DROP TABLE IF EXISTS employees CASCADE;
DROP TABLE IF EXISTS cobol_files CASCADE;

\echo 'Done.'
\echo ''

-- ============================================================================
-- Core JCL System Tables
-- ============================================================================

\echo 'Creating core JCL tables...'

-- Job data storage (JSON payloads from web/API)
CREATE TABLE jcl_job_data (
    job_id BIGINT PRIMARY KEY,
    json_data TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE jcl_job_data IS 'Stores JSON input data for job execution';
COMMENT ON COLUMN jcl_job_data.job_id IS 'Unique job identifier (timestamp-based)';
COMMENT ON COLUMN jcl_job_data.json_data IS 'JSON payload containing job parameters';

-- Index for time-based queries
CREATE INDEX idx_jcl_job_data_created ON jcl_job_data(created_at DESC);

-- Process tracking table
CREATE TABLE active_jobs (
    pid INTEGER PRIMARY KEY,
    job_id BIGINT NOT NULL,
    program_name VARCHAR(255) NOT NULL,
    started_at TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE active_jobs IS 'Tracks currently executing jobs';
COMMENT ON COLUMN active_jobs.pid IS 'Process ID of the running job';
COMMENT ON COLUMN active_jobs.job_id IS 'Associated job_id from jcl_job_data';

-- Index for job_id lookups
CREATE INDEX idx_active_jobs_job_id ON active_jobs(job_id);

\echo 'Core tables created.'
\echo ''

-- ============================================================================
-- Business Data Tables (Examples)
-- ============================================================================

\echo 'Creating sample business tables...'

-- Employee table (for payroll demo)
CREATE TABLE employees (
    emp_id INTEGER PRIMARY KEY,
    emp_name TEXT NOT NULL,
    hourly_rate INTEGER NOT NULL,  -- Stored as cents (e.g., 2500 = $25.00)
    hours_worked INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE employees IS 'Sample employee data for payroll processing demo';
COMMENT ON COLUMN employees.hourly_rate IS 'Hourly rate in cents (2500 = $25.00/hour)';

-- COBOL file storage (virtual file system)
CREATE TABLE cobol_files (
    file_name VARCHAR(255) PRIMARY KEY,
    file_data BYTEA NOT NULL,
    record_length INTEGER,
    record_count INTEGER,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE cobol_files IS 'Virtual file system for COBOL I/O operations';
COMMENT ON COLUMN cobol_files.file_data IS 'Binary file content';

\echo 'Business tables created.'
\echo ''

-- ============================================================================
-- Sample Data
-- ============================================================================

\echo 'Inserting sample data...'

INSERT INTO employees (emp_id, emp_name, hourly_rate, hours_worked) VALUES
(1, 'John Smith', 2500, 40),      -- $25.00/hr, 40 hours
(2, 'Jane Doe', 3000, 35),        -- $30.00/hr, 35 hours
(3, 'Bob Wilson', 2750, 38),      -- $27.50/hr, 38 hours
(4, 'Alice Johnson', 3200, 40),   -- $32.00/hr, 40 hours
(5, 'Charlie Brown', 2800, 42);   -- $28.00/hr, 42 hours

\echo 'Sample data inserted.'
\echo ''

-- ============================================================================
-- Verify Installation
-- ============================================================================

\echo '============================================================================'
\echo 'Database initialization complete!'
\echo '============================================================================'
\echo ''

-- Show created tables
\echo 'Tables created:'
SELECT 
    schemaname as schema,
    tablename as table_name,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY tablename;

\echo ''

-- Show sample data count
\echo 'Sample data:'
SELECT 
    'employees' as table_name,
    COUNT(*) as record_count 
FROM employees;

\echo ''

-- Test query
\echo 'Sample employee data:'
SELECT 
    emp_id,
    emp_name,
    hourly_rate / 100.0 as hourly_rate_dollars,
    hours_worked
FROM employees
ORDER BY emp_id
LIMIT 3;

\echo ''
\echo 'You can now start the JCL services:'
\echo '  ./JCL_daemon_exec &'
\echo '  ./JCL_http_gateway_exec &'
\echo ''
\echo 'Then open web/index.html in your browser.'
\echo '============================================================================'